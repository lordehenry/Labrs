## Short description of the problem

## Steps to reproduce

## Environment

* `vim` or `nvim` version
* `git` version
* current vimagit version or (or SHA1)
* OS
* terminal or gvim
